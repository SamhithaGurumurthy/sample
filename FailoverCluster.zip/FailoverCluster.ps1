Configuration FailoverFeature
{
param ($MachineName)

  Node $MachineName
  {
     WindowsFeature FailoverFeature 
        { 
            Ensure = "Present" 
            Name      = "Failover-clustering" 
        } 
    
  }
} 